﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Models;
using Newtonsoft.Json;

namespace $safeprojectname$.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home

        [HttpGet]
        public ActionResult Index()
        {
           

            return View();
        }

        [HttpPost]
        public ActionResult Kayit(userinfo person)
        {
            
            int a, b, sonuc;

            a = DateTime.Now.Year;
            b = person.dogumtarihi.Year;

            sonuc = a - b;
            
            string jsonstring = JsonConvert.SerializeObject(person);
            string jsyas = JsonConvert.SerializeObject(sonuc);



            ViewBag.MyObj = jsonstring;
            ViewBag.Sonuc = jsyas;

             

            return View();


        }
    }
}