﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Models
{
    public class userinfo
    {


        public string TbAd { get; set; }

        public string TbSoyad { get; set; }

        public DateTime dogumtarihi { get; set; }

        

        

    }


}